// One-off review evidence: run the real live.cjs against local fixture responses.
'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const root = path.resolve(__dirname, '../..');
const address = '0x1111111111111111111111111111111111111111';
const contract = '0x5555555555555555555555555555555555555555';
const revision = 'local-gemini-review';
let enabled = false;
let unexpectedWrites = [];
let requestCount = 0;
const server = http.createServer(async (req, res) => {
  requestCount++;
  const url = new URL(req.url, 'http://127.0.0.1');
  const p = url.pathname;
  const json = data => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(data)); };
  try {
    if (!['GET', 'HEAD'].includes(req.method) && p !== '/api/wallet/token') {
      unexpectedWrites.push(req.method + ' ' + p);
      res.statusCode = 405;
      return json({error: 'read-only fixture'});
    }
    if (p === '/healthz') { res.setHeader('X-App-Version', revision); return json({status: 'ok'}); }
    if (/^\/static\/[a-zA-Z0-9._-]+$/.test(p)) {
      res.setHeader('Content-Type', p.endsWith('.css') ? 'text/css' : p.endsWith('.json') ? 'application/json' : 'text/javascript');
      return res.end(await fs.readFile(path.join(root, 'internal/web', p)));
    }
    const template = {'/': 'index.html', '/solana/': 'solana.html', '/tron/': 'tron.html'}[p];
    if (template) {
      const html = (await fs.readFile(path.join(root, 'internal/web/templates', template), 'utf8'))
        .replace(/{{if \.Public}}([\s\S]*?){{else}}([\s\S]*?){{end}}/g, (_, yes, no) => no)
        .replace(/{{if \.Public}}([\s\S]*?){{end}}/g, '')
        .replace(/{{if \.Shared}}([\s\S]*?){{end}}/g, (_, yes) => yes)
        .replaceAll('{{.Native}}', 'ETH');
      res.setHeader('Content-Type', 'text/html');
      return res.end(html);
    }
    if (p === '/api/network') return json({chainId:11155111, block:'100', checkedAt:new Date().toISOString(), blockTime:new Date().toISOString()});
    if (p === '/api/wallet') return json({exists:true, address, chainId:11155111, csrfToken:'fixture', exchange:{}});
    if (p === '/api/balance') return json({address, eth:'1', wei:'1000000000000000000', block:'100', checkedAt:new Date().toISOString()});
    if (p === '/api/wallet/accounts') return json([{id:'', name:'主要錢包', address, archived:false}]);
    if (p === '/api/wallet/vault') return json({enabled, contract:enabled?contract:'', balance:enabled?'0.03':'', balanceRaw:enabled?'30000000000000000':''});
    if (p === '/api/wallet/history') return json({transactions:[]});
    if (p === '/api/wallet/activity') return json({page:1, pages:1, totalTransactions:0, transactions:[], totals:[]});
    if (p === '/api/wallet/scan') return json({enabled:false, start:90, next:91, finalized:100, tokens:[]});
    if (p === '/api/wallet/token') return json({contract:address, symbol:'TEST', decimals:18, balance:'0', balanceRaw:'0', allowance:'0', allowanceRaw:'0'});
    if (p === '/api/faucet') return json({enabled:false, csrfToken:'fixture'});
    const family = p.match(/^\/(solana|tron)\/api\/(status|balance|history)$/);
    if (family) {
      const sol = family[1] === 'solana';
      if (family[2] === 'status') return json({exists:true, address:sol?'CghaUzuHcKaSKQG3UtoZzMafEPmnRk1V6LUN2Hdp8XWa':'TUEZSdKsoDHQMeZwihtdoBiN46zxhGWYdH', csrfToken:'fixture'});
      if (family[2] === 'balance') return json(sol?{sol:'0.1', slot:100}:{trx:'100', active:true, bandwidth:600, energy:0});
      return json([]);
    }
    res.statusCode = 404;
    json({error:'unhandled fixture path: ' + p});
  } catch (error) { res.statusCode = 500; json({error:String(error)}); }
});

(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const results = [];
  const cases = [
    ['default-disabled', false, '', 0, 'vault disabled'],
    ['default-enabled', true, '', 0, 'vault enabled'],
    ['expected-enabled', true, contract, 0, 'vault enabled'],
    ['expected-disabled', false, contract, 1, 'the expected deployed vault must be enabled'],
    ['expected-mismatch', true, address, 1, 'server uses the expected deployed contract'],
    ['expected-malformed', true, 'not-an-address', 1, 'EXPECTED_VAULT_ADDRESS must be an EVM address'],
  ];
  try {
    for (const [name, state, expected, code, marker] of cases) {
      enabled = state; unexpectedWrites = []; requestCount = 0;
      const started = Date.now();
      const env = {...process.env, EXPECTED_REVISION:revision, EXPECTED_VAULT_ADDRESS:expected, WALLET_DEMO_URL:'http://127.0.0.1:' + server.address().port};
      const result = await run(process.execPath, ['tests/browser/live.cjs'], {cwd:root, env, timeout:40000, maxBuffer:1024*1024})
        .then(value => ({...value, code:0}), error => error);
      const output = (result.stdout || '') + (result.stderr || '');
      await fs.writeFile(path.join(__dirname, name + '.log'), output);
      const record = {name, expected_exit_code:code, exit_code:result.code, killed:!!result.killed, duration_seconds:(Date.now()-started)/1000, request_count:requestCount};
      results.push(record);
      await fs.writeFile(path.join(__dirname, 'live-results.json'), JSON.stringify(results, null, 2) + '\n');
      assert.equal(result.killed || false, false, name + ' must exit without being killed');
      assert.equal(result.code, code, name + ': ' + output);
      assert.ok(output.includes(marker), name + ': expected diagnostic is present');
      assert.deepEqual(unexpectedWrites, [], 'live checks must not submit state-changing fixture requests');
      if (code === 0) assert.ok(output.includes('revision unchanged'), name + ' completed the whole live script');
      if (name === 'expected-malformed') assert.equal(requestCount, 0, 'malformed expectation rejected before network');
      console.log('PASS', name, 'exit=' + result.code, 'seconds=' + record.duration_seconds);
    }
  } finally {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
